<?php
    session_start();
    require "fungsi.php";

    if(!isset($_SESSION['login'])){
        header('location: index.php');
        exit;
    }

    $text = tampil("SELECT * FROM teks");
    $gambar = tampil("SELECT * FROM gambar");
    $quote = tampil("SELECT * FROM quote");
    $link = tampil("SELECT * FROM link");

    // var_dump($kabupaten); die();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="style/styleadmin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">
    <script src="admin.js" defer></script>
</head>
<body>
    <div class="dashboard">
        <h1>Albar<span>Admin.id</span></h1>
        <div class="wrapper">
            <p>Halaman<br><span>admin</span></p>
            <button class="btn"><i class="far fa-building"></i> Text</button>
            <button class="btn"><i class="fas fa-suitcase-rolling"></i> Gambar</button>
            <button class="btn"><i class="bi bi-chat-left-dots"></i> Quote</button>
            <button class="btn"><i class="bi bi-chat-left-dots"></i> Link</button>
            <button class="btn"><i class="bi bi-box-arrow-left"></i> keluar</button>
        </div>
    </div>
    <div class="container">
    <table border="1" class="my-table ">
            <thead>
                <th>No.</th>
                <th>Nama</th>
                <th>Text</th>
                <th>Aksi</th>
            </thead>
            <tbody>
            <?php
                foreach ($text as $i => $menu) :
            ?>
            <tr>
                <td> <?php echo $i+1?></td>
                <td> <?php echo $menu['nama']?></td>
                <td> <?php echo $menu['text']?></td>
                <td>
                    <a href="edit_text.php?id=<?= $menu['id'] ?>">Edit</a>
                    <a href="tambah_text.php" class="btn btn-primary">Tambah</a>
                </td>
            </tr>
            <?php
                endforeach;
            ?>
            </tbody>
    </table>




    <table border="1" class="my-table hide">
            <thead>
                <th>No.</th>
                <th>Nama</th>
                <th>Gambar</th>
                <th>Aksi</th>
            </thead>
            <tbody>
            <?php
                foreach($gambar as $menu):
            ?>
            <tr>
                <td> <?php echo $i+1?></td>
                <td> <?php echo $menu['nama']?></td>
                <td> <?php echo $menu['gambar']?></td>
                <td>
                    <a href="edit_gambar.php?id=<?= $menu['id'] ?>">Edit</a>
                    <a href="tambah_gambar.php" class="btn btn-primary">Tambah</a>
                </td>
            </tr>
            <?php
            $i++;
                endforeach;
            ?>
            </tbody>
    </table>

    <table border="1" class="my-table hide">
            <thead>
                <th>No.</th>
                <th>Nama</th>
                <th>Quote</th>
                <th>Aksi</th>
            </thead>
            <tbody>
            <?php
                $i=0;
                foreach($quote as $menu):
            ?>
            <tr>
                <td> <?php echo $i+1?></td>
                <td> <?php echo $menu['nama']?></td>
                <td> <?php echo $menu['quote']?></td>
                <td>
                    <a href="edit_quote.php?id=<?= $menu['id'] ?>">Edit</a>
                    <a href="tambah_quote.php" class="btn btn-primary">Tambah</a>
                </td>
            </tr>
            <?php
            $i++;
                endforeach;
            ?>
            </tbody>
    </table>

    <table border="1" class="my-table hide">
            <thead>
                <th>No.</th>
                <th>Nama</th>
                <th>Link</th>
                <th>Aksi</th>
            </thead>
            <tbody>
            <?php
                $i=0;
                foreach($link as $menu):
            ?>
            <tr>
                <td> <?php echo $i+1?></td>
                <td> <?php echo $menu['nama']?></td>
                <td> <?php echo $menu['link']?></td>
                <td>
                    <a href="edit_link.php?id=<?= $menu['id'] ?>">Edit</a>
                    <a href="tambah_link.php" class="btn btn-primary">Tambah</a>
                </td>
            </tr>
            <?php
            $i++;
                endforeach;
            ?>
            </tbody>
    </table>

    </div>

</body>
</html>