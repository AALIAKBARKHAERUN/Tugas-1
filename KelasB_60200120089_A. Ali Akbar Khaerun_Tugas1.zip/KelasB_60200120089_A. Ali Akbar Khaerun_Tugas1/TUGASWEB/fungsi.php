<?php
    $koneksi = mysqli_connect("localhost", "root", "", "web_cutime") or die();
    
    function tampil($query){
        global $koneksi;

        $result = mysqli_query($koneksi, $query);

        // $data = (mysqli_fetch_assoc($result));

        // $rows = [];

        while($data = mysqli_fetch_assoc($result)){
            
            $rows[] = $data;
        }

        return $rows;
    }

    function edit_tex($data) {

        global $koneksi;

        $id = $data['id'];

        $nama = $data['nama'];
        $text = $data['text'];

        $query = "UPDATE teks SET nama = '$nama', text = '$text' WHERE id = '$id'";
        mysqli_query($koneksi, $query);

        return mysqli_affected_rows($koneksi);

    }

    function edit_gam($data) {

        global $koneksi;

        $id = $data['id'];

        $nama = $data['nama'];
        $gambar = $data['gambar'];

        $query = "UPDATE gambar SET nama = '$nama', gambar = '$gambar' WHERE id = '$id'";
        mysqli_query($koneksi, $query);

        return mysqli_affected_rows($koneksi);

    }

    function edit_quot($data) {

        global $koneksi;

        $id = $data['id'];

        $nama = $data['nama'];
        $quote = $data['quote'];

        $query = "UPDATE quote SET nama = '$nama', quote = '$quote' WHERE id = '$id'";
        mysqli_query($koneksi, $query);

        return mysqli_affected_rows($koneksi);

    }

    function edit_lin($data) {

        global $koneksi;

        $id = $data['id'];

        $nama = $data['nama'];
        $link = $data['link'];

        $query = "UPDATE link SET nama = '$nama', link = '$link' WHERE id = '$id'";
        mysqli_query($koneksi, $query);

        return mysqli_affected_rows($koneksi);

    }

    function tambah_tex($data){
        global $koneksi;
    
        $nama = $data['nama'];
        $text = $data['text'];
    
        
    
        $query = "INSERT INTO teks VALUES('','$nama','$text')";
    
        mysqli_query($koneksi,$query);
        if (mysqli_affected_rows($koneksi) > 0){
            header("location:admin-page.php?status=1");
        }
        else {
            header("location:tambah_text.php?status=0");
        }
    
    }

    function tambah_gam($data){
        global $koneksi;
    
        $nama = $data['nama'];
        $gambar = upload($_FILES);
    
        
    
        $query = "INSERT INTO style VALUES('','$nama','$gambar')";
    
        mysqli_query($koneksi,$query);
        if (mysqli_affected_rows($koneksi) > 0){
            header("location:admin-page.php?status=1");
        }
        else {
            header("location:tambah_gambar.php?status=0");
        }
    
    }

    function tambah_quot($data){
        global $koneksi;
    
        $nama = $data['nama'];
        $quote = $data['quote'];
        
    
        
    
        $query = "INSERT INTO quote VALUES('','$nama','$quote')";
    
        mysqli_query($koneksi,$query);
        if (mysqli_affected_rows($koneksi) > 0){
            header("location:admin-page.php?status=1");
        }
        else {
            header("location:tambah_quote.php?status=0");
        }
    
    }

    function tambah_lin($data){
        global $koneksi;
    
        $nama = $data['nama'];
        $link = $data['link'];
        
    
        
    
        $query = "INSERT INTO link VALUES('','$nama','$link')";
    
        mysqli_query($koneksi,$query);
        if (mysqli_affected_rows($koneksi) > 0){
            header("location:admin-page.php?status=1");
        }
        else {
            header("location:tambah_link.php?status=0");
        }
    
    }
    
    function upload($files){
        $gambar = $files["gambar"];
        $error = $files["gambar"];
        $tmp = $files["gambar"];
        $format = explode(".",$gambar);
        $format = strtolower(end($format));
    
        if($error === 4){
            return false;
        }
    
        $gambar = date("ymdis").".".$format;
        // var_dump($gambar);die();    
        move_uploaded_file($tmp,"img/".$gambar);
    
        return $gambar;
    }
?>