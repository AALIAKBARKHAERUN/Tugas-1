<?php 

    require 'fungsi.php';

    $id = $_GET["id"];

    $result = tampil("SELECT * FROM teks WHERE id = $id")[0];

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/edit_text.css">
    <title>Document</title>
</head>
<body>

    <div class="container">

        <h1>Edit Data Teks</h1>

        <form action="./fungsi/edit_t.php" method="post">
            <label for="id">id : </label>
            <input type="text" id="id" name="id" value="<?= $result['id'] ?>" readonly>
            <label for="nama">nama : </label>
            <input type="text" name="nama" id="nama" value="<?= $result['nama'] ?>">
            <label for="text">text : </label>
            <input type="text" name="teks" id="teks" value="<?= $result['text'] ?>">
            
            <button type="submit">submit</button>
        </form>
    </div>
    
</body>
</html>