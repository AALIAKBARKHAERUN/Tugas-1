<?php
    require "fungsi.php";

    $text = tampil("SELECT * FROM teks");

    $gambar = tampil("SELECT * FROM gambar");

    $quote = tampil("SELECT * FROM quote");

    $link = tampil("SELECT * FROM link");

    // var_dump($kabupaten); die();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <title>index</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="style/style1.css">
    <link rel="stylesheet" href="style/style2.css">
    <link rel="stylesheet" href="style/style3.css">
    <link rel="stylesheet" href="style/style4.css">
</head>
<body>
  
  <div id="s-1">
    <nav>
        <a href="#s-1"><h1><img src="" alt="" srcset="" width="25px"> CuTime</h1></a>
        <a href="#s-1"><i class="bi bi-house-door" style="margin-right: 10px;"></i>Beranda</a>
        <a href="#s-2"><i class="bi bi-signpost-2" style="margin-right: 10px;"></i>Kategori</a>
        <a href="#s-4"><i class="bi bi-info-circle" style="margin-right: 10px;" ></i>Tentang</a>
        <a href="login.php"><i class="bi bi-door-open" style="margin-right: 10px;"></i>Login</a>
    </nav>
    <div class="hero-item">
        <h4>Selamat Datang Di <br/>
            Website <br/>
            Albar</h4>     
        <h1>Curhat<span>Time</span></h1>
        <h6>Dimana anda bisa meluapkan isi hati sepuasnya tanpa ada yang membatasi</h6>
    </div>
  </div>

  <div id="s-2">
    <ul>
        <li><a href="index.php?teks"><i class="fas fa-message"></i></a></li>
        <li><a href="index.php?gambar"><i class="fa-solid fa-camera"></i></a></li>
        <li><a href="index.php?quote"><i class="fa-solid fa-quote-left"></i></i></a></li>
        <li><a href="index.php?link"><i class="fa-solid fa-link"></i></a></li>
    </ul>
  </div>

  <div id="s-3">
    <div class="container">
        <?php
            foreach ($text as $i => $rows) :
        ?>
        <div class="title">
            <img src="pt.PNG" alt="">
            <div class="info">
                <h4 class="nama"><?php echo $rows['nama']?></h4>
                <p class="twitter-handle"><?php echo $i+1?></p>
            </div>
        </div>

        <div class="tweet">
            <p><?php echo $rows['text']?></p>
        </div>
        <?php
            endforeach;
        ?>
        <div class="time-date">
            <p>15:30 &middot; 2 april 2022 <span>Cutime for Android</span></p>
        </div>

        <div class="button">
            <ul>
                <li><a href=""><i class="fa-solid fa-comment"></i></a></li>
                <li><a href=""><i class="fa-solid fa-heart"></i></a></li>
                <li><a href=""><i class="fa-solid fa-share"></i></a></li>
                <li><a href=""><i class="fa-solid fa-upload"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
            foreach ($gambar as $i => $rows) :
        ?>
        <div class="title">
            <img src="pt.PNG" alt="">
            <div class="info">
                <h4 class="nama"><?php echo $rows['nama']?></h4>
                <p class="twitter-handle"><?php echo $i+1?></p>
            </div>
        </div>

        <div class="tweet">
            <p><?php echo $rows['gambar']?></p>
        </div>
        <?php
            endforeach;
        ?>
        <div class="time-date">
            <p>15:30 &middot; 2 april 2022 <span>Cutime for Android</span></p>
        </div>

        <div class="button">
            <ul>
                <li><a href=""><i class="fa-solid fa-comment"></i></a></li>
                <li><a href=""><i class="fa-solid fa-heart"></i></a></li>
                <li><a href=""><i class="fa-solid fa-share"></i></a></li>
                <li><a href=""><i class="fa-solid fa-upload"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
            foreach ($quote as $i => $rows) :
        ?>
        <div class="title">
            <img src="pt.PNG" alt="">
            <div class="info">
                <h4 class="nama"><?php echo $rows['nama']?></h4>
                <p class="twitter-handle"><?php echo $i+1?></p>
            </div>
        </div>

        <div class="tweet">
            <p><?php echo $rows['quote']?></p>
        </div>
        <?php
            endforeach;
        ?>
        <div class="time-date">
            <p>15:30 &middot; 2 april 2022 <span>Cutime for Android</span></p>
        </div>

        <div class="button">
            <ul>
                <li><a href=""><i class="fa-solid fa-comment"></i></a></li>
                <li><a href=""><i class="fa-solid fa-heart"></i></a></li>
                <li><a href=""><i class="fa-solid fa-share"></i></a></li>
                <li><a href=""><i class="fa-solid fa-upload"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
            foreach ($link as $i => $rows) :
        ?>
        <div class="title">
            <img src="pt.PNG" alt="">
            <div class="info">
                <h4 class="nama"><?php echo $rows['nama']?></h4>
                <p class="twitter-handle"><?php echo $i+1?></p>
            </div>
        </div>

        <div class="tweet">
            <p><?php echo $rows['link']?></p>
        </div>
        <?php
            endforeach;
        ?>
        <div class="time-date">
            <p>15:30 &middot; 2 april 2022 <span>Cutime for Android</span></p>
        </div>

        <div class="button">
            <ul>
                <li><a href=""><i class="fa-solid fa-comment"></i></a></li>
                <li><a href=""><i class="fa-solid fa-heart"></i></a></li>
                <li><a href=""><i class="fa-solid fa-share"></i></a></li>
                <li><a href=""><i class="fa-solid fa-upload"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
            foreach ($quote as $i => $rows) :
        ?>
        <div class="title">
            <img src="pt.PNG" alt="">
            <div class="info">
                <h4 class="nama"><?php echo $rows['nama']?></h4>
                <p class="twitter-handle"><?php echo $i+1?></p>
            </div>
        </div>

        <div class="tweet">
            <p><?php echo $rows['quote']?></p>
        </div>
        <?php
            endforeach;
        ?>
        <div class="time-date">
            <p>15:30 &middot; 2 april 2022 <span>Cutime for Android</span></p>
        </div>

        <div class="button">
            <ul>
                <li><a href=""><i class="fa-solid fa-comment"></i></a></li>
                <li><a href=""><i class="fa-solid fa-heart"></i></a></li>
                <li><a href=""><i class="fa-solid fa-share"></i></a></li>
                <li><a href=""><i class="fa-solid fa-upload"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
            foreach ($link as $i => $rows) :
        ?>
        <div class="title">
            <img src="pt.PNG" alt="">
            <div class="info">
                <h4 class="nama"><?php echo $rows['nama']?></h4>
                <p class="twitter-handle"><?php echo $i+1?></p>
            </div>
        </div>

        <div class="tweet">
            <p><?php echo $rows['link']?></p>
        </div>
        <?php
            endforeach;
        ?>
        <div class="time-date">
            <p>15:30 &middot; 2 april 2022 <span>Cutime for Android</span></p>
        </div>

        <div class="button">
            <ul>
                <li><a href=""><i class="fa-solid fa-comment"></i></a></li>
                <li><a href=""><i class="fa-solid fa-heart"></i></a></li>
                <li><a href=""><i class="fa-solid fa-share"></i></a></li>
                <li><a href=""><i class="fa-solid fa-upload"></i></a></li>
            </ul>
        </div>
    </div>
  </div>
  
  
  <footer id="s-4">
      <div class="rowe">
        <div class="cole">
          <!-- <img src="logo.png" class="logo"> -->
          <p class="cole">All information displayed in CuTime was independently selected by our editors. The material on this site may not be reproduced, distributed, transmitted, cached or otherwise used, except with the prior written permission of Albar Ventures.</p>
        </div>
        <div class="cole">
          <h3>Office <div class="underline"><span></span></div></h3>
          <p>Minasa Upa</p>
          <p>Makassar, Sulawesi Selatan</p>
          <p>90221, Indonesia</p>
          <p class="email-id">aaliakbar214@gmail.com</p>
          <h4>+62 817-0339-8181</h4>
        </div>
        <div class="cole">
          <h3>Links <div class="underline"><span></span></div></h3>
          <ul>
            <li><a href="">Home</a></li>
            <li><a href="aboutme.php">About us</a></li>
            <li><a href="contact.php">Contacts</a></li>
          </ul>
        </div>
        <div class="cole">
          <h3>Newsletter <div class="underline"><span></span></div></h3>
          <form action="" class="news">
            <i class="far fa-envelope"></i>
            <input class="inpute" type="email" placeholder="Enter Your Email id" required>
            <button class="buttone" type="submit"><i class="fas fa-arrow-right"></i></button>
          </form>
          <div class="social-icons">
            <a href="https://instagram.com/valbarv?utm_medium=copy_link"><i class="fab fa-instagram"></i></a>
            <a href="https://m.facebook.com/valbarv.valbarv?tsid=0.9624872894642649&source=result"><i class="fab fa-facebook-f"></i></a>
            <a href="https://wa.me/qr/67W7WRMYV4HCL1"><i class="fab fa-whatsapp"></i></a>
            <a href="https://twitter.com/valbarv18"><i class="fab fa-twitter"></i></a>
          </div>
        </div>
        <div class="col"></div>
      </div>
      <hr class="hr">
      <p class="copyright">CuTime ©2021 A. Ali Akbar Khaerun | All Right Reserved</p>      
    </footer>

<script src="script.js"></script>
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</body>
</html>